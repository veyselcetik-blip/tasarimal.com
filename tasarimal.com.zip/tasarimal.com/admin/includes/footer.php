<?php
require_once __DIR__ . '/includes/bootstrap.php';
</main>
</div>
<script src="assets/admin_script.js"></script>
</body>
</html>