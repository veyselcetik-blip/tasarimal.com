<footer class="footer">
  <div class="container">
    <p>&copy; <?= date('Y') ?> Veysel Platform. Tüm Hakları Saklıdır.</p>
  </div>
</footer>

<?php
require_once __DIR__ . '/includes/bootstrap.php';
 include 'includes/modals.php'; ?>

<script src="assets/script.js"></script>

</body>
</html>